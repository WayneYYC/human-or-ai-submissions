# Training-data exploration

![Class balance, text length and formatting](overview.png)

Open `summary.csv` for counts and distribution summaries, and `examples_local_only.csv` for three seeded examples per class. Labels are supplied annotations, not conclusions from reading the prose.

Ask: Are the classes balanced? How much do length distributions overlap? Is a difference typical or driven by the tails? Do the examples show variation within each class? Six examples cannot establish a genre or style rule.

Words are whitespace-separated tokens; characters include whitespace; newlines count literal newline characters, not rendered lines. These are descriptive measurements, not classifier features or causal explanations. No cleaning, feature selection, or model changes are applied. Keep raw example exports out of Git.
